﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MacroGUI.ViewModels
{
    public sealed class MacroVM
    {
        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                if (_name != value)
                {
                    _name = value ?? string.Empty;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Name)));
                }
            }
        }

        private string _memo = string.Empty;
        public string Memo
        {
            get => _memo;
            set
            {
                if (_memo != value)
                {
                    _memo = value ?? string.Empty;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Memo)));
                }
            }
        }

        public ObservableCollection<MacroStepVM> Steps { get; } = new ObservableCollection<MacroStepVM>();

        public MacroVM(string name)
        {
            _name = name ?? string.Empty;
        }
        public event PropertyChangedEventHandler? PropertyChanged;

    }
}
